import React, { Component } from 'react';
import firebase from '../configurations/fbaseconfig';

import stylesheets from '../stylesheets/books.css'

const db = firebase.firestore();
class Books extends Component {
    state ={
        books : [],
        BookName:'',
        Author:'',
        Price:'',
        ISBN:'',
        Username:'',
        Password:'',
    }



    componentDidMount(){
        db.collection('Books-Available').get().then(data =>{
            data.docs.forEach(doc => {
                this.setState({books : [...this.state.books, doc.data()]
                });
                // console.log(doc.data());
                
            })
        })
    
    }
    
    render() {
        return (
            <div className='book-container jumbotron'>
                <h1>Books Available</h1>
                <br/>
                {this.state.books.length?( 
                    this.state.books.map(item =>{
                        return(
                            <Col lg={3} md={6} xs={12} style={{marginBottom: "30px"}} key={item}>
                            <Card>
                                <Card.Body>
                                    <p>{item.Bookname}</p>
                                    <p>{item.Author}</p>
                                    <p>{item.Price}</p>
                                    <p>{item.ISBN}</p>
                                </Card.Body>
                            </Card>                          
                        </Col>
                            // <div className='book-each'>
                            //     <p>{item.Bookname}</p>
                            //     <p>{item.Author}</p>
                            //     <p>{item.Price}</p>
                            //     <p>{item.ISBN}</p>
                            //     <hr/>
                            // </div>


                        )
                    })
                ) :(
                    <p>loading.........</p>
                )}

                
            </div>
        )
    }
}

export default Books;