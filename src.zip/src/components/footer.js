import React, { Component } from 'react'
import { Container, Row, Col } from 'react-bootstrap'

class Footer extends Component {
    render() {
        return (
            <div>
                <Container>
                    <Row>
                        <Col>Developed by JAY'S Solutions</Col>
                        <Col>www.jaysolutions@gmail.com</Col>
                        <Col>011-2255896</Col>
                    
                    </Row>
                </Container>
                <br/>

            </div>
        )
    }
}

export default Footer
